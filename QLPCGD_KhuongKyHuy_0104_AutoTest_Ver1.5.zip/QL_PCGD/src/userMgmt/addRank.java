package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonRank;
import pageObject.addRankElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class addRank {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonRank jsonHelper = new jsonRank();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		authentication authen = new authentication(driver);
		authen.login();

		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/AcademicDegreeRank");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));

		WebElement addRankButton = wait.until(ExpectedConditions.elementToBeClickable(addRankElements.ADD_MAJOR_BUTTON));
	    addRankButton.click();
	    //Thread.sleep(3000);
	}
	  
 /* 	@Test (priority = 0)
	public void tc_saveRankSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputRankfromJson(0);
		
		
		String successMsg = driver.findElement(By.className("toast-message")).getText();
		System.out.println(successMsg.toString());
		Assert.assertEquals(successMsg, "Lưu thành công!");
		Thread.sleep(2000);
		driver.quit();
	}*/

	@Test (priority = 1)
	public void tc_assignmentLectureSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputRankfromJson(1);
		//Thread.sleep(2000);
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		Assert.assertEquals(errMsg, "Mã cấp bậc này đã tồn tại!");
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(addRankElements.CLOSE_BUTTON);
	    closeButton.click();
	}
	
	public void inputRankfromJson(int iNumber) throws InterruptedException {
	
		WebElement id = driver.findElement(addRankElements.MA_HOCHAM_HOCVI_INPUT);
		id.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String idValue = jsonData.get(iNumber).get(0);
		WebElement idOption = driver.findElement(By.xpath("//li[contains(text(), '" + idValue + "')]"));
		idOption.click();

		WebElement maGV = driver.findElement(addRankElements.MA_CAPBAC_INPUT);
		maGV.sendKeys(jsonData.get(iNumber+1).get(0));
		
		WebElement submitButton = driver.findElement(addRankElements.SUBMIT_BUTTON);
		submitButton.click();
	}
}
