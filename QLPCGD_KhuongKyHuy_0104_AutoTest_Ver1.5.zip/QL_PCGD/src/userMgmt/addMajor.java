package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonMajor;
import pageObject.addMajorElements;
import pageObject.addUserElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class addMajor {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonMajor jsonHelper = new jsonMajor();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");	
		driver = new ChromeDriver();	
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Major");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));

		WebElement addMajorButton = wait.until(ExpectedConditions.elementToBeClickable(addMajorElements.ADD_MAJOR_BUTTON));
		addMajorButton.click();
	    //Thread.sleep(3000);
	}
	  
	/*@Test (priority = 0)
	public void tc_saveMajorSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputMajorfromJson(0);
		
		//Thread.sleep(2000);
		String successMsg = driver.findElement(By.className("toast-message")).getText();	
		System.out.println(successMsg.toString());
		Assert.assertEquals(successMsg, "Lưu thành công!");
	}*/

	@Test (priority = 1)
	public void tc_saveMajorWithDuplicationMessage() throws InterruptedException {
	    Thread.sleep(1000);
		inputMajorfromJson(0);
		
		//Thread.sleep(2000);
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		System.out.println(errMsg.toString());
		Assert.assertEquals(errMsg, "Mã ngành này đã tồn tại!");
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(addUserElements.CLOSE_BUTTON);
	    closeButton.click();
	}

	public void inputMajorfromJson(int iNumber) throws InterruptedException {
		WebElement idmajor = driver.findElement(addMajorElements.MA_NGANH_INPUT);
		idmajor.sendKeys(jsonData.get(iNumber).get(0));
		
		WebElement major = driver.findElement(addMajorElements.TEN_NGANH_INPUT);
		major.sendKeys(jsonData.get(iNumber+1).get(0));
		
		WebElement sumary = driver.findElement(addMajorElements.ACROMY_INPUT);
		sumary.sendKeys(jsonData.get(iNumber+2).get(0));
		
		WebElement program = driver.findElement(addMajorElements.EDUCATION_PROGRAM_SELECT);
		program.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String programValue = jsonData.get(iNumber+3).get(0);
		WebElement programOption = driver.findElement(By.xpath("//li[contains(text(), '" + programValue + "')]"));
		programOption.click();
		
		
		
		WebElement submitButton = driver.findElement(addMajorElements.SUBMIT_BUTTON);
		submitButton.click();
		Thread.sleep(3000);
	}	
}
