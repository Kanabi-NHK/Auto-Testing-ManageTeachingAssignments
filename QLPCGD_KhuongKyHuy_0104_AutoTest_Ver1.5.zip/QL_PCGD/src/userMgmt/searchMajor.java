package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonMajor;
import pageObject.addMajorElements;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class searchMajor {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonMajor jsonHelper = new jsonMajor();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Major");
	}

	  
 	@Test (priority = 0)
	public void tc_searchMajorSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputTermfromJson(0);
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblMajor\"]/thead/tr/th[2]")).getText();
		System.out.println(errMsg.toString());
		String errMsg1 = driver.findElement(By.xpath("//*[@id=\"tblMajor\"]/tbody/tr/td[2]")).getText();
		System.out.println(errMsg1.toString());
		String errMsg2 = driver.findElement(By.xpath("//*[@id=\"tblMajor\"]/thead/tr/th[3]")).getText();
		System.out.println(errMsg2.toString());
		String errMsg3 = driver.findElement(By.xpath("//*[@id=\"tblMajor\"]/tbody/tr/td[3]")).getText();
		System.out.println(errMsg3.toString());
		Thread.sleep(3000);
	}
 	
  	@Test (priority = 1)
	public void tc_searchMajorWithDuplicationMessage() throws InterruptedException {
  		Thread.sleep(1000);
		WebElement tk = driver.findElement(addMajorElements.SEARCH);
		tk.clear();
		WebElement nd = driver.findElement(addMajorElements.SEARCH);
		nd.sendKeys("Công nghệ kiểm thử");
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblMajor\"]/tbody/tr/td")).getText();
		System.out.println(errMsg.toString());
		Thread.sleep(3000);
	}
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	public void inputTermfromJson(int iNumber) throws InterruptedException {
		WebElement maGV = driver.findElement(addMajorElements.SEARCH);
		maGV.sendKeys(jsonData.get(iNumber+1).get(0));
	}
}




