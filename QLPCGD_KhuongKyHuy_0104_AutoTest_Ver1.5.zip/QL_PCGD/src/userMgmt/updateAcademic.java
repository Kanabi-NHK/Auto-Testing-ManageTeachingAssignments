package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonAcademic;
import pageObject.addAcademicElements;
import pageObject.addUserElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class updateAcademic {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonAcademic jsonHelper = new jsonAcademic();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		authentication authen = new authentication(driver);
		authen.login();

		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/AcademicDegree");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));

		WebElement updateAcademicButton = wait.until(ExpectedConditions.elementToBeClickable(addAcademicElements.UPDATE_BUTTON));
		updateAcademicButton.click();
	    //Thread.sleep(3000);
	}
	  
	@Test (priority = 0)
	public void tc_updateAcademicSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputAcademicfromJson(0);
		
		//Thread.sleep(2000);
		String successMsg = driver.findElement(By.className("toast-message")).getText();	
		Assert.assertEquals(successMsg, "Cập nhật thành công!");
	}

	
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(addUserElements.CLOSE_BUTTON);
	    closeButton.click();
	}

	public void inputAcademicfromJson(int iNumber) throws InterruptedException {

		WebElement nameHH = driver.findElement(addAcademicElements.TEN_HOCHAM_HOCVI_INPUT);
		nameHH.sendKeys(jsonData.get(iNumber+4).get(0));
			
		WebElement submitButton = driver.findElement(addAcademicElements.SUBMIT_BUTTON);
		submitButton.click();
		Thread.sleep(3000);
	}	
}
