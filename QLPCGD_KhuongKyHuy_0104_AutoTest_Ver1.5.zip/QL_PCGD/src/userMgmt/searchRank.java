package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonRank;
import pageObject.addRankElements;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class searchRank {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonRank jsonHelper = new jsonRank();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/AcademicDegreeRank");
	}

	  
 	@Test (priority = 0)
	public void tc_searchTermSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputRankfromJson(0);
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblAcademicDegreeRank\"]/thead/tr/th[1]")).getText();
		System.out.println(errMsg.toString());
		String errMsg1 = driver.findElement(By.xpath("//*[@id=\"tblAcademicDegreeRank\"]/tbody/tr[1]/td")).getText();
		System.out.println(errMsg1.toString());
		String errMsg2 = driver.findElement(By.xpath("//*[@id=\"tblAcademicDegreeRank\"]/tbody/tr[2]/td[1]")).getText();
		System.out.println(errMsg2.toString());
		Thread.sleep(3000);
	}
 	
  	@Test (priority = 1)
	public void tc_searchTermWithDuplicationMessage() throws InterruptedException {
  		Thread.sleep(1000);
		WebElement tk = driver.findElement(addRankElements.SEARCH);
		tk.clear();
		WebElement nd = driver.findElement(addRankElements.SEARCH);
		nd.sendKeys("Queen");
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblAcademicDegreeRank\"]/tbody/tr/td")).getText();
		System.out.println(errMsg.toString());
		Thread.sleep(3000);
	}
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	public void inputRankfromJson(int iNumber) throws InterruptedException {
		WebElement maGV = driver.findElement(addRankElements.SEARCH);
		maGV.sendKeys(jsonData.get(iNumber+1).get(0));
	}
}




