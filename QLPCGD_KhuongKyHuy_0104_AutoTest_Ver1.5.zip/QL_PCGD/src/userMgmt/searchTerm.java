package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonTerm;
import pageObject.addTermElements;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class searchTerm {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonTerm jsonHelper = new jsonTerm();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Term");
	}

	  
 	@Test (priority = 0)
	public void tc_searchTermSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputTermfromJson(0);String errMsg = driver.findElement(By.xpath("//*[@id=\"tblTerm\"]/thead/tr/th[1]")).getText();
		System.out.println(errMsg.toString());
		String errMsg1 = driver.findElement(By.xpath("//*[@id=\"tblTerm\"]/tbody/tr/td[1]")).getText();
		System.out.println(errMsg1.toString());
		Thread.sleep(3000);
	}
 	
  	@Test (priority = 1)
	public void tc_deleteClassSuccessfully() throws InterruptedException {
  		Thread.sleep(1000);
		WebElement tk = driver.findElement(addTermElements.SEARCH);
		tk.clear();
		WebElement nd = driver.findElement(addTermElements.SEARCH);
		nd.sendKeys("992");
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblTerm\"]/tbody/tr/td")).getText();
		System.out.println(errMsg.toString());
		Thread.sleep(3000);
	}
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	public void inputTermfromJson(int iNumber) throws InterruptedException {
		WebElement maGV = driver.findElement(addTermElements.SEARCH);
		maGV.sendKeys(jsonData.get(iNumber).get(0));
	}
}




