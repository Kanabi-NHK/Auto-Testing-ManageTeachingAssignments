package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonProfile;
import pageObject.ProfileElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class updateProfile {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonProfile jsonHelper = new jsonProfile();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		driver = new ChromeDriver();
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));
		WebElement logo = wait.until(ExpectedConditions.elementToBeClickable(ProfileElements.LOGO));
		logo.click();
		WebElement updateProflieButton = wait.until(ExpectedConditions.elementToBeClickable(ProfileElements.PROFILE));
		updateProflieButton.click();
	}
	  
  	@Test (priority = 0)
	public void tc_updateProfileSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputRankfromJson(0);
		String successMsg = driver.findElement(By.id("swal2-html-container")).getText();
		System.out.println(successMsg.toString());
		Assert.assertEquals(successMsg, "Cập nhật thành công!");
		Thread.sleep(2000);
	}
  	@Test (priority = 1)
	public void tc_updateProfileWithEror() throws InterruptedException {
	    Thread.sleep(1000);
		inputRankfromJson(0);
		WebElement id = driver.findElement(ProfileElements.ID);
		id.clear();
		id.sendKeys("{}");
		String eror = driver.findElement(By.id("//*[@id=\"staff_id-error\"]")).getText();
		System.out.println(eror.toString());
		Thread.sleep(2000);
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(ProfileElements.CONFIRM);
	    closeButton.click();
	}
	public void inputRankfromJson(int iNumber) throws InterruptedException {
	
		WebElement id = driver.findElement(ProfileElements.ID);
		id.clear();
		id.sendKeys(jsonData.get(iNumber).get(0));
		WebElement name = driver.findElement(ProfileElements.NAME);
		name.clear();
		name.sendKeys(jsonData.get(iNumber+1).get(0));
		
		WebElement submitButton = driver.findElement(ProfileElements.SUBMIT_BUTTON);
		submitButton.click();
	}
}
	