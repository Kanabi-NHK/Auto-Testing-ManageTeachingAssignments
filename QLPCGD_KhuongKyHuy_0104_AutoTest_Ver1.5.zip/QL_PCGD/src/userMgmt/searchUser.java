package userMgmt;

import qlpcHelper.authentication; 
import qlpcHelper.jsonSearchUser;
import pageObject.searchUserElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class searchUser {
    
    WebDriver driver;
    String projectPath = System.getProperty("user.dir");

    static jsonSearchUser jsontimkiem = new jsonSearchUser();
    static List<List<String>> jsonData = jsontimkiem.readDataFromJson();

    @BeforeClass
    public void beforeClass() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
        
        driver = new ChromeDriver();
        
        authentication authen = new authentication(driver);
        authen.login();

        Thread.sleep(1000);
        driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/User");
    }

    @BeforeMethod
    public void loadForm() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement addUserButton = wait.until(ExpectedConditions.elementToBeClickable(searchUserElements.ADD_USER_BUTTON));
        addUserButton.click();
    }
      
    @Test(priority = 1)
   

    public void tc_timkiemnguoidung() throws InterruptedException {
        System.out.println("Test 1");

        Thread.sleep(1000);
        inputUserfromJson(0);

        // Kết quả mong đợi
        String expectedUser = "Trương Vô Kỵ";

        // Tìm tất cả các phần tử <td> chứa văn bản "Trương Vô Kỵ"
        List<WebElement> tdElements = driver.findElements(By.xpath("//td[contains(text(),'Trương Vô Kỵ')]"));

        // Kiểm tra xem có phần tử nào thỏa mãn điều kiện không
        if (!tdElements.isEmpty()) {
            System.out.println("Người dùng 'Trương Vô Kỵ' tồn tại.");
            
            // Kết quả thực tế
            String actualUser = tdElements.get(0).getText().trim(); // Lấy văn bản trong phần tử đầu tiên
            System.out.println("Kết quả thực tế khớp với kết quả mong đợi: " + actualUser);

            // Kiểm tra kết quả thực tế với kết quả mong đợi
            Assert.assertEquals(actualUser, expectedUser, "Kết quả thực tế không khớp với kết quả mong đợi");
            
        } else {
            Assert.fail("Không tìm thấy phần tử chứa văn bản 'Trương Vô Kỵ'");
        }
    }

    @Test(priority = 1)
    

    public void tc_timkiemnguoidung2() throws InterruptedException {
        System.out.println("Test 2");
        WebElement searchField2 = driver.findElement(searchUserElements.SEACH);
        searchField2.clear();
        Thread.sleep(1000);
        inputUserfromJson(1);
        // Kết quả mong đợi
        String expectedUser2 = "truongvoky123@vanlanguni.vn";
        // Tìm tất cả các phần tử <td> chứa văn bản "Trương Vô Kỵ"
        List<WebElement> tdElements2 = driver.findElements(By.xpath("//td[@class='sorting_1']"));
        // Kiểm tra xem có phần tử nào thỏa mãn điều kiện không
        if (!tdElements2.isEmpty()) {
            System.out.println("Người dùng 'Trương Vô Kỵ' tồn tại.");          
            // Kết quả thực tế
            String actualUser2 = tdElements2.get(0).getText().trim(); // Lấy văn bản trong phần tử đầu tiên
            System.out.println("Kết quả thực tế khớp với kết quả mong đợi: " + actualUser2);
            // Kiểm tra kết quả thực tế với kết quả mong đợi
            Assert.assertEquals(actualUser2, expectedUser2, "Kết quả thực tế không khớp với kết quả mong đợi");         
        } else {
            Assert.fail("Không tìm thấy phần tử chứa văn bản 'Trương Vô Kỵ'");
        }
    }
    @Test(priority = 3)
    public void tc_timkiemnguoidung3() throws InterruptedException {
        System.out.println("Test 3");
        Thread.sleep(1000);
        WebElement searchField3 = driver.findElement(searchUserElements.SEACH);
        searchField3.clear();
        searchField3.sendKeys("Trương Bá Phi");

        // Kết quả mong đợi
        String expectedUser3 = "Trương Vô Kỵ"; // Thay đổi giá trị mong đợi
        Thread.sleep(2000); // Đợi kết quả xuất hiện
        WebElement actualResultElement3 = driver.findElement(By.xpath("//td[@class='dataTables_empty']"));
        String actualResult3 = actualResultElement3.getText();
        
        if (!actualResult3.equals(expectedUser3)) {
            System.out.println("Kết quả tìm kiếm không có!");
            System.out.println("Kết quả thực tế:" + actualResult3);
            System.out.println("Kết quả mong đợi: " + expectedUser3);
        } else {
            System.out.println("Kết quả tìm kiếm đúng!");
        }
    }


    @AfterClass
    public void tearDown() {
        driver.quit();
    }
    public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(searchUserElements.CLOSE_BUTTON);
	    closeButton.click();
	}
    
    public void inputUserfromJson(int iNumber) throws InterruptedException {
        WebElement tenGV = driver.findElement(searchUserElements.SEACH);
        tenGV.sendKeys(jsonData.get(iNumber + 1).get(0)); // Assuming the name is at index 1 in your JSON data
        
        WebElement loaiGV = driver.findElement(searchUserElements.CHOSE_GV);
        loaiGV.click();
        loaiGV.sendKeys(jsonData.get(iNumber + 3).get(0)); // Assuming the name is at index 3 in your JSON data
        loaiGV.sendKeys(Keys.ENTER);

        WebElement roleSelect = driver.findElement(searchUserElements.CHOSE_ROLE);
        roleSelect.click();
        roleSelect.sendKeys(jsonData.get(iNumber + 4).get(0)); // Assuming the name is at index 4 in your JSON data
        roleSelect.sendKeys(Keys.ENTER);
        
        WebElement hienthi = driver.findElement(searchUserElements.HIENTHI);
        hienthi.click();
        hienthi.sendKeys(jsonData.get(iNumber + 5).get(0)); // Assuming the name is at index 5 in your JSON data
        hienthi.sendKeys(Keys.ENTER);
    }
    
}
