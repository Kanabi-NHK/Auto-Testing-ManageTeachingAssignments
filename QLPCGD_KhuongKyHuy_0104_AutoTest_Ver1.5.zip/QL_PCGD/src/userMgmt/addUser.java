package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonHelper;
import pageObject.addUserElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class addUser {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonHelper jsonHelper = new jsonHelper();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		authentication authen = new authentication(driver);
		authen.login();

		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/User");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));

		WebElement addUserButton = wait.until(ExpectedConditions.elementToBeClickable(addUserElements.ADD_USER_BUTTON));
	    addUserButton.click();
	    //Thread.sleep(3000);
	}
	  
  	@Test (priority = 0)
	public void tc_saveUserSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputUserfromJson(0);
		
		
		String successMsg = driver.findElement(By.className("toast-message")).getText();
		System.out.println(successMsg.toString());
		Assert.assertEquals(successMsg, "Lưu thành công!");
		Thread.sleep(2000);
		driver.quit();
	}

	@Test (priority = 1)
	public void tc_saveUserWithDuplicationMessage() throws InterruptedException {
	    Thread.sleep(1000);
		inputUserfromJson(0);
		//Thread.sleep(2000);
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		System.out.println(errMsg.toString());
		Assert.assertEquals(errMsg, "Người dùng đã có trong hệ thống!");
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(addUserElements.CLOSE_BUTTON);
	    closeButton.click();
	}
	
	public void inputUserfromJson(int iNumber) throws InterruptedException {
		WebElement maGV = driver.findElement(addUserElements.MA_GIANG_VIEN_INPUT);
		maGV.sendKeys(jsonData.get(iNumber).get(0));
		WebElement tenGV = driver.findElement(addUserElements.TEN_GIANG_VIEN_INPUT);
		tenGV.sendKeys(jsonData.get(iNumber+1).get(0));	
		WebElement emailGV = driver.findElement(addUserElements.EMAIL_INPUT);
		emailGV.sendKeys(jsonData.get(iNumber+2).get(0));	
		WebElement loaiGV = driver.findElement(addUserElements.LOAI_GIANG_VIEN_SELECT);
		loaiGV.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String loaigvValue = jsonData.get(iNumber+3).get(0);
		WebElement loaigvOption = driver.findElement(By.xpath("//li[contains(text(), '" + loaigvValue + "')]"));
		loaigvOption.click();

		WebElement roleSelect = driver.findElement(addUserElements.ROLE_SELECT);
		roleSelect.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String roleValue = jsonData.get(iNumber+4).get(0);
		WebElement roleOption = driver.findElement(By.xpath("//li[contains(text(), '" + roleValue + "')]"));
		roleOption.click();

		// Input Quốc tịch
		String quocTichValue = jsonData.get(iNumber+5).get(0);
		if (quocTichValue.equals("Việt Nam")) {
			WebElement quocTich = driver.findElement(By.id("is_vietnamese"));
			quocTich.click();
		}
		
		WebElement submitButton = driver.findElement(addUserElements.SUBMIT_BUTTON);
		submitButton.click();
	}
}
