package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonAcademic;
import pageObject.addAcademicElements;
import pageObject.addUserElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class addAcademic {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");

	static jsonAcademic jsonHelper = new jsonAcademic();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");	
		driver = new ChromeDriver();	
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/AcademicDegree");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));
		WebElement addAcademicButton = wait.until(ExpectedConditions.elementToBeClickable(addAcademicElements.ADD_ACADEMIC_BUTTON));
		addAcademicButton.click();
	    //Thread.sleep(3000);
	}
	 
	@Test (priority = 0)
	public void tc_saveAcademicSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputTermfromJson(0);
		
		//Thread.sleep(2000);
		String successMsg = driver.findElement(By.className("toast-message")).getText();
		System.out.println(successMsg.toString());
		Assert.assertEquals(successMsg, "Lưu thành công!");
	}

	@Test (priority = 1)
	public void tc_saveAcademicWithDuplicationMessage() throws InterruptedException {
	    Thread.sleep(1000);
		inputTermfromJson(0);
		
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		System.out.println(errMsg.toString());
		Assert.assertEquals(errMsg, "Mã học hàm, học vị này đã tồn tại!");
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(addUserElements.CLOSE_BUTTON);
	    closeButton.click();
	}

	public void inputTermfromJson(int iNumber) throws InterruptedException {
		WebElement maHH = driver.findElement(addAcademicElements.MA_HOCHAM_HOCVI_INPUT);
		maHH.sendKeys(jsonData.get(iNumber).get(0));	
		WebElement nameHH = driver.findElement(addAcademicElements.TEN_HOCHAM_HOCVI_INPUT);
		nameHH.sendKeys(jsonData.get(iNumber+1).get(0));	
		WebElement levels = driver.findElement(addAcademicElements.THUTU_INPUT);
		levels.sendKeys(jsonData.get(iNumber+2).get(0));
		
		

		
		WebElement submitButton = driver.findElement(addAcademicElements.SUBMIT_BUTTON);
		submitButton.click();
		Thread.sleep(3000);
	}	
}
