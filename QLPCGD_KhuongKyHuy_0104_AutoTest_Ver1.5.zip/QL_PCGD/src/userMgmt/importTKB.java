package userMgmt;

import qlpcHelper.authentication;  
import qlpcHelper.jsonTKB;
import pageObject.importTKBElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;

import java.awt.AWTException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class importTKB {
    
    WebDriver driver;
    String projectPath = System.getProperty("user.dir");

    static jsonTKB jsonTKB = new jsonTKB();
    static List<List<String>> jsonData = jsonTKB.readDataFromJson();

    @BeforeClass
    public void beforeClass() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");
        
        driver = new ChromeDriver();
        
        authentication authen = new authentication(driver);
        authen.login();

        driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Timetable/Import");
    }

    @BeforeMethod
    public void loadForm() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement addUserButton = wait.until(ExpectedConditions.elementToBeClickable(importTKBElements.ADD_USER_BUTTON));
        addUserButton.click();
        
    }
      
    @Test(priority = 1)

    public void tc_importTKB() throws InterruptedException, AWTException {
        System.out.println("Test 1:");

    	inputUserfromJson(0);

 		Thread.sleep(1000);
 		importTKBElements authen = new importTKBElements();
        authen.uploadfile();
      
		WebElement submit = driver.findElement(importTKBElements.SUBMIT_BUTTON);
        submit.click();	
		Thread.sleep(2000);
		WebElement update = driver.findElement(importTKBElements.UPDATE_BUTTON);
		update.click();
		WebElement updatett = driver.findElement(importTKBElements.UPDATE_NEXT);
		updatett.click();
		
        System.out.println("Đã Cập Nhật thành công");

 	
    }
    /*
    @Test(priority = 2)

    public void tc_importTKB2() throws InterruptedException, AWTException {
        System.out.println("Test 2:");

    	inputUserfromJson(0);

 		Thread.sleep(1000);
 		importTKBElements authen = new importTKBElements();
        authen.uploadfile();
      
		WebElement submit = driver.findElement(importTKBElements.SUBMIT_BUTTON);
        submit.click();	
		Thread.sleep(2000);
		WebElement Replace = driver.findElement(importTKBElements.Replace_BUTTON);
		Replace.click();
		WebElement updatett = driver.findElement(importTKBElements.UPDATE_NEXT);
		updatett.click();
		WebElement oktt = driver.findElement(importTKBElements.OKT_BUTTON);
		oktt.click();
        System.out.println("Đã thay thế thành công");
        
    }
    @Test(priority = 3)

    public void tc_importTKB3() throws InterruptedException, AWTException {
        System.out.println("Test 3:");

    	inputUserfromJson(0);

 		Thread.sleep(1000);
 		importTKBElements authen = new importTKBElements();
        authen.uploadfile();
      
		WebElement submit2 = driver.findElement(importTKBElements.SUBMIT_BUTTON);
        submit2.click();	
		Thread.sleep(2000);
		WebElement huy1 = driver.findElement(importTKBElements.CLOSE_BUTTON);
		huy1.click();	
		WebElement updatett = driver.findElement(importTKBElements.UPDATE_NEXT);
		updatett.click();
        System.out.println("Đã Hủy import Thời khóa biểu");
        
    } */
    

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
    public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(importTKBElements.CLOSE_BUTTON);
	    closeButton.click();
	}
    public void inputUserfromJson(int iNumber) throws InterruptedException {
    	WebElement loaiGV = driver.findElement(importTKBElements.HOCKY_INPUT);
		loaiGV.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String loaigvValue = jsonData.get(iNumber).get(0);
		WebElement loaigvOption = driver.findElement(By.xpath("//li[contains(text(), '" + loaigvValue + "')]"));
		loaigvOption.click();

		WebElement roleSelect = driver.findElement(importTKBElements.NGHANH_INPUT);
		roleSelect.click();
		String roleValue = jsonData.get(iNumber+1).get(0);
		WebElement roleOption = driver.findElement(By.xpath("//li[contains(text(), '" + roleValue + "')]"));
		roleOption.click();
        WebElement import_TKB = driver.findElement(importTKBElements.IMPORT_TKB);
        import_TKB.click();	


    }
    
}
