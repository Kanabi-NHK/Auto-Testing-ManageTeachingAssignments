package userMgmt;

import qlpcHelper.authentication;
import pageObject.AssignmentElements;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class deleteClass {
	
	WebDriver driver;
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Timetable/Assign");
	}

	  
 	@Test (priority = 0)
	public void tc_deleteClassSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
	    WebElement select = driver.findElement(By.xpath("//*[@id=\"341623\"]"));
		select.click();
		WebElement xoa = driver.findElement(AssignmentElements.DELETE);
		xoa.click();
		WebElement dataxoa = driver.findElement(AssignmentElements.DATA_DELETE);
		dataxoa.sendKeys("221_71ITBS10103_0201");
		WebElement cf = driver.findElement(AssignmentElements.CONFIRM_DELETE);
		cf.click();
		String successMsg = driver.findElement(By.className("toast-message")).getText();	
		Assert.assertEquals(successMsg, "Xóa lớp thành công!");
	}
 	
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}	
	
}




