package userMgmt;

import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import qlpcHelper.authentication;

import java.awt.AWTException;
import org.openqa.selenium.interactions. Actions;


public class viewSchedule {
    private WebDriver driver;
    @BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Timetable/Assign");
	}
    @Test(priority = 0)
    public void TC1_TestViewWeekSchedule() throws InterruptedException, AWTException {
    	WebElement schedule = driver.findElement(By.xpath("//*[@id=\"main-menu-navigation\"]/li[4]/a/span"));
    	schedule.click(); 
		WebElement select = driver.findElement(By.xpath("//*[@id=\"main-menu-navigation\"]/li[4]/ul/li[3]/a/span"));
		select.click(); 
		
		WebElement term = driver.findElement(By.xpath("//*[@id=\"select2-term-container\"]"));
		term.click();
		WebElement data = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div[1]/div[1]/div/span[2]/span/span[1]/input"));
		data.click();
		data.sendKeys("998");
		Actions actions = new Actions (driver); 
		actions.sendKeys (Keys.ENTER); 
		actions.build().perform();
		
		
        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    } 
    @Test(priority = 1)
    public void TC2_TestViewWeekSchedule() throws InterruptedException, AWTException {
        
    	WebElement lecturers = driver.findElement(By.xpath("//*[@id=\"select2-lecturer-container\"]"));
    	lecturers.click();
		Thread.sleep(1000);
		WebElement data1 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div[1]/div[3]/div/span[2]/span/span[1]/input"));
		data1.click();
		data1.sendKeys("Nguyễn Hoài Khương"); 
		Actions actions = new Actions (driver); 
		actions.sendKeys (Keys.ENTER); 
		actions.build().perform();
		
        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
        
    }
    @Test(priority = 2)
    public void TC3_TestViewLecturersSchedule() throws InterruptedException, AWTException {
        
    	WebElement week = driver.findElement(By.xpath("//*[@id=\"select2-week-container\"]"));
		week.click();
		Thread.sleep(2000);
		WebElement data1 = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div[1]/div[2]/div/span[2]/span/span[1]/input"));
		data1.click();
		Thread.sleep(2000);
		data1.sendKeys("Tuần 9");
		Thread.sleep(2000);  
		Actions actions = new Actions (driver); 
		actions.sendKeys (Keys.ENTER); 
		actions.build().perform();
		String errMsg = driver.findElement(By.xpath("//*[@id=\"personalTimetableDiv\"]/div[2]/div/strong")).getText();
		System.out.println(errMsg.toString());
		String errMsg1 = driver.findElement(By.xpath("//*[@id=\"personalTimetableDiv\"]/div[3]/table/tbody/tr[4]/td[3]/div/b[1]")).getText();
		System.out.println(errMsg1.toString());
        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.quit();
    }    
}

     
