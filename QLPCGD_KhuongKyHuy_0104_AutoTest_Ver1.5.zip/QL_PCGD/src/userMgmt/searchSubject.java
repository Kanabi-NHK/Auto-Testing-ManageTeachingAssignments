package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonHelper;
import pageObject.updateSubjectElements;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class searchSubject {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonHelper jsonHelper = new jsonHelper();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Subject");
		WebElement year = driver.findElement(By.xpath("//*[@id=\"select2-term-container\"]"));
		year.click();
		WebElement data = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div[1]/div[1]/div/span[2]/span/span[1]/input"));
		data.click();
		data.sendKeys("998");
		Actions actions = new Actions (driver); 
		actions.sendKeys (Keys.ENTER); 
		actions.build().perform();
	}
	
	  
	@Test (priority = 0)
	public void tc_searchSubjectSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
	    WebElement tk = driver.findElement(updateSubjectElements.SEARCH);
		tk.clear();
		WebElement nd = driver.findElement(updateSubjectElements.SEARCH);
		nd.sendKeys("Nhập môn Công nghệ thông tin");
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblSubject\"]/thead/tr/th[2]")).getText();
		System.out.println(errMsg.toString());
		String errMsg1 = driver.findElement(By.xpath("//*[@id=\"tblSubject\"]/tbody/tr/td[2]")).getText();
		System.out.println(errMsg1.toString());
		String errMsg2 = driver.findElement(By.xpath("//*[@id=\"tblSubject\"]/thead/tr/th[3]")).getText();
		System.out.println(errMsg2.toString());
		String errMsg3 = driver.findElement(By.xpath("//*[@id=\"tblSubject\"]/tbody/tr/td[3]")).getText();
		System.out.println(errMsg3.toString());
		Thread.sleep(3000);
	}
 	
  	@Test (priority = 1)
	public void tc_searchSubjectWithDuplicationMessage() throws InterruptedException {
  		Thread.sleep(1000);
		WebElement tk = driver.findElement(updateSubjectElements.SEARCH);
		tk.clear();
		WebElement nd = driver.findElement(updateSubjectElements.SEARCH);
		nd.sendKeys("Lập trình Web cơ bản");
		String errMsg = driver.findElement(By.xpath("//*[@id=\"tblSubject\"]/tbody/tr/td")).getText();
		System.out.println(errMsg.toString());
		Thread.sleep(3000);
	}
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	
}




