package userMgmt;

import qlpcHelper.authentication;
import org.testng.annotations.Test;
import pageObject.ProfileElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class logIn_logOut {
	
	WebDriver driver;
	  
  	@Test (priority = 0)
	public void tc_LoginAccount() throws InterruptedException {
  		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");	
		driver = new ChromeDriver();	
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/");
		String successMsg = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/h3")).getText();
		System.out.println(successMsg.toString());
		Thread.sleep(2000);
	}

	@Test (priority = 1)
	public void tc_LogoutAccount() throws InterruptedException {
		WebElement logo = driver.findElement(ProfileElements.LOGO);
		logo.click();
		Thread.sleep(2000);
		WebElement logout = driver.findElement(ProfileElements.LOGOUT);
		logout.click();
		Thread.sleep(2000);
		String successMsg = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/div/div/h6")).getText();
		System.out.println(successMsg.toString());
		Thread.sleep(2000);
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	
}
