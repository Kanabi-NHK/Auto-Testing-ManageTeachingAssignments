package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonPrice;
import pageObject.updatePriceElements;

import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class updateCoefficient {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonPrice jsonHelper = new jsonPrice();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();
	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/PriceCoefficient");
		WebElement year = driver.findElement(By.xpath("//*[@id=\"select2-year-container\"]"));
		year.click();
		WebElement data = driver.findElement(By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div[1]/div/div/span[2]/span/span[1]/input"));
		data.click();
		data.sendKeys("2023 - 2024");
		Actions actions = new Actions (driver); 
		actions.sendKeys (Keys.ENTER); 
		actions.build().perform();
	}
	
	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));
		WebElement heso = driver.findElement(updatePriceElements.HESO);
	    heso.click();
		WebElement update = wait.until(ExpectedConditions.elementToBeClickable(updatePriceElements.UPDATE_HESO));
		update.click();
	}
	  
 	@Test (priority = 0)
	public void tc_updateCoefficientSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputRankfromJson(0);
		String successMsg = driver.findElement(By.className("toast-message")).getText();
		System.out.println(successMsg.toString());
		Assert.assertEquals(successMsg, "Lưu thành công!");
		Thread.sleep(2000);
	}
 	
  	@Test (priority = 1)
	public void tc_updateCoefficientWithDuplicationMessage() throws InterruptedException {
  		Thread.sleep(1000);
		WebElement tk = driver.findElement(updatePriceElements.TA);
		tk.clear();
		WebElement nd = driver.findElement(updatePriceElements.TA);
		nd.sendKeys("10");
		WebElement submitButton = driver.findElement(updatePriceElements.LUU);
		submitButton.click();
		String errMsg = driver.findElement(By.xpath("//*[@id=\"foreign_coefficient-error\"]")).getText();
		System.out.println(errMsg.toString());
		Thread.sleep(3000);
	}
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}
  	public void closeForm() throws InterruptedException {
		Thread.sleep(3000);
	    WebElement closeButton = driver.findElement(updatePriceElements.CLOSE_BUTTON);
	    closeButton.click();
	}
	public void inputRankfromJson(int iNumber) throws InterruptedException {
		WebElement tv = driver.findElement(updatePriceElements.TV);
		tv.clear();
		tv.sendKeys(jsonData.get(iNumber+1).get(0));
		
		WebElement ta = driver.findElement(updatePriceElements.TA);
		ta.clear();
		ta.sendKeys(jsonData.get(iNumber+2).get(0));
		
		WebElement lt = driver.findElement(updatePriceElements.LT);
		lt.clear();
		lt.sendKeys(jsonData.get(iNumber+3).get(0));
		
		WebElement th = driver.findElement(updatePriceElements.TH);
		th.clear();
		th.sendKeys(jsonData.get(iNumber+4).get(0));
		
		WebElement submitButton = driver.findElement(updatePriceElements.LUU);
		submitButton.click();
		Thread.sleep(3000);
	}
}




