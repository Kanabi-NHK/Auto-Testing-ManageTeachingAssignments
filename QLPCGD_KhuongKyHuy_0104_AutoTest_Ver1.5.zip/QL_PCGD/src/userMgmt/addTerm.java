package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonTerm;
import pageObject.addTermElements;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class addTerm {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonTerm jsonHelper = new jsonTerm();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();	
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Term");
	}

	@BeforeMethod
	public void loadForm() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(1000));
		WebElement addUserButton = wait.until(ExpectedConditions.elementToBeClickable(addTermElements.ADD_TERM_BUTTON));
	    addUserButton.click();
	}
	  
	@Test (priority = 0)
	public void tc_saveTermSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		inputTermfromJson(0);
		
		//Thread.sleep(2000);
		String successMsg = driver.findElement(By.className("toast-message")).getText();	
		Assert.assertEquals(successMsg, "Lưu thành công!");
	}

	@Test (priority = 1)
	public void tc_saveTermWithDuplicationMessage() throws InterruptedException {
	    Thread.sleep(1000);
		inputTermfromJson(0);
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		System.out.println(errMsg.toString());
		Assert.assertEquals(errMsg, "Học kỳ này đã được tạo trong hệ thống!");
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}

	public void inputTermfromJson(int iNumber) throws InterruptedException {
		WebElement maGV = driver.findElement(addTermElements.MA_TERM_INPUT);
		maGV.sendKeys(jsonData.get(iNumber).get(0));
		
		WebElement yearstart = driver.findElement(addTermElements.YEAR_START_SELECT);
		yearstart.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String yearstartValue = jsonData.get(iNumber+1).get(0);
		WebElement yearstartOption = driver.findElement(By.xpath("//li[contains(text(), '" + yearstartValue + "')]"));
		yearstartOption.click();
		
		WebElement yearsend = driver.findElement(addTermElements.YEAR_END_SELECT);
		yearsend.click();
		Thread.sleep(1000); // Wait for the dropdown options to appear
		String yearsendValue = jsonData.get(iNumber+2).get(0);
		WebElement yearsendOption = driver.findElement(By.xpath("//li[contains(text(), '" + yearsendValue + "')]"));
		yearsendOption.click();
		
		
		WebElement day = driver.findElement(By.xpath("//*[@id=\"term-form\"]/div[5]/input[2]"));
		day.click();
		WebElement day1 = driver.findElement(By.xpath("/html/body/div[4]/div[2]/div/div[2]/div/span[23]"));
		day1.click();

		WebElement week = driver.findElement(addTermElements.WEEK_INPUT);
		week.sendKeys(jsonData.get(iNumber+3).get(0));
		WebElement lesson = driver.findElement(addTermElements.LESSON_INPUT);
		lesson.sendKeys(jsonData.get(iNumber+4).get(0));
		WebElement clas = driver.findElement(addTermElements.CLASS_INPUT);
		clas.sendKeys(jsonData.get(iNumber+5).get(0));

		
		WebElement submitButton = driver.findElement(addTermElements.SUBMIT_BUTTON);
		submitButton.click();
		Thread.sleep(3000);
	}	
}
