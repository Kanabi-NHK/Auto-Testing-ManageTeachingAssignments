package userMgmt;

import qlpcHelper.authentication;
import qlpcHelper.jsonLecture;
import pageObject.AssignmentElements;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.Assert;

public class lecturersAssignment {
	
	WebDriver driver;
	String projectPath = System.getProperty("user.dir");
	static jsonLecture jsonHelper = new jsonLecture();
	static List<List<String>> jsonData = jsonHelper.readDataFromJson();

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");	
		driver = new ChromeDriver();	
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Timetable/Assign");
	}
  
	@Test (priority = 0)
	public void tc_assignmentLectureSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);
		WebElement select = driver.findElement(By.xpath("//*[@id=\"341642\"]"));
		select.click(); 

		WebElement type = driver.findElement(By.id("select2-lecturer-bp-container"));
		type.click(); 
		WebElement type1 = driver.findElement(By.xpath("//*[@id=\"popover321037\"]/div[2]/div/div/span[2]/span/span[1]/input"));
		type1.click();
	    WebElement data2 = driver.findElement(AssignmentElements.DATA);
	    data2.sendKeys("Nguyễn Hoài Khương");
	    WebElement click = driver.findElement(AssignmentElements.CONFIRM_PHANCONG);
	    click.click();
		String successMsg = driver.findElement(By.className("toast-message")).getText();	
		Assert.assertEquals(successMsg, "Thành công!");
	}

	@Test (priority = 1)
	public void tc_assignmentLectureWithDuplicationMessage() throws InterruptedException {
	    Thread.sleep(1000);
	    WebElement select = driver.findElement(By.xpath("//*[@id=\"341642\"]"));
		select.click(); 
		WebElement type = driver.findElement(By.xpath("//*[@id=\"select2-lecturer-h7-container\"]/span"));
		type.click(); 
		WebElement type1 = driver.findElement(By.xpath("//*[@id=\"popover321037\"]/div[2]/div/div/span[2]/span/span[1]/input"));
		type1.click();
	    WebElement data2 = driver.findElement(AssignmentElements.DATA);
	    data2.sendKeys("Nguyễn Hoài Khương");
	    WebElement click = driver.findElement(AssignmentElements.CONFIRM_PHANCONG);
	    click.click();
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		System.out.println(errMsg.toString());
		Assert.assertEquals(errMsg, "Giảng viên này đã có lớp trong tiết học này!");
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
	public void inputLecturefromJson(int iNumber) throws InterruptedException {
		WebElement data = driver.findElement(AssignmentElements.DATA);
		data.sendKeys(jsonData.get(iNumber+2).get(0)); 	
	}
}
