package userMgmt;

import qlpcHelper.authentication;
import pageObject.addMajorElements;

import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class deleteMajor {
	
	WebDriver driver;

	@BeforeClass
	public void beforeClass() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "c:\\chromedriver.exe");		
		driver = new ChromeDriver();		
		authentication authen = new authentication(driver);
		authen.login();
		Thread.sleep(3000);
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Major");
	}

	  
 	@Test (priority = 0)
	public void tc_deleteMajorSuccessfully() throws InterruptedException {
	    Thread.sleep(1000);	
		WebElement deleteButton = driver.findElement(addMajorElements.DELETE_BUTTON);
		deleteButton.click();	
		Thread.sleep(1000);	
		WebElement confirmdeleteButton = driver.findElement(addMajorElements.CONFIRM_DELETE_BUTTON);
		confirmdeleteButton.click();
		String successMsg = driver.findElement(By.className("toast-message")).getText();
		System.out.println(successMsg.toString());
		Thread.sleep(2000);
	}
  	@Test (priority = 1)
	public void tc_deleteMajorWithDuplicationMessage() throws InterruptedException {
	    Thread.sleep(1000);
		WebElement deleteButton = driver.findElement(addMajorElements.DELETE_BUTTON);
		deleteButton.click();	
		Thread.sleep(1000);
		WebElement confirmdeleteButton = driver.findElement(addMajorElements.CONFIRM_DELETE_BUTTON);
		confirmdeleteButton.click();	
		String errMsg = driver.findElement(By.xpath("//*[@id=\"swal2-html-container\"]")).getText();
		System.out.println(errMsg.toString());
		Thread.sleep(2000);
	}
  	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}




