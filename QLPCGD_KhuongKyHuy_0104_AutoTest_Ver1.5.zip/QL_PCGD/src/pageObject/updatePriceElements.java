package pageObject;

import org.openqa.selenium.By;

public class updatePriceElements {

    public static final By UPDATE_PRICE = By.xpath("//*[@id=\"tblStandard\"]/tbody/tr[1]/td[3]/a[1]/i");
    public static final By DATA_PRICE = By.id("price");
    public static final By UPDATE_HESO = By.xpath("//*[@id=\"tblCoefficient\"]/tbody/tr/td[5]/a/i");
    public static final By HESO = By.id("coefficient-tab");
    public static final By TV = By.id("vietnamese_coefficient");
    public static final By TA = By.id("foreign_coefficient");
    public static final By LT = By.id("theoretical_coefficient");
    public static final By TH = By.id("practice_coefficient");
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"unitprice-form\"]/div[3]/button[2]");
    public static final By LUU = By.xpath("//*[@id=\"coefficient-form\"]/div[3]/button[2]");
    public static final By CLOSE_BUTTON = By.xpath("/html/body/div[5]/div[1]/button");
      
}
