package pageObject;
import org.openqa.selenium.By;

public class ProfileElements {
	public static final By ID = By.id("staff_id");
	public static final By NAME = By.id("full_name");
    public static final By LOGO = By.id("dropdown-user");
    public static final By PROFILE = By.xpath("/html/body/div[2]/nav/div/ul/li[2]/div/a[1]");
    public static final By LOGOUT = By.xpath("/html/body/div[2]/nav/div/ul/li[2]/div/a[2]"); 
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"profile-form\"]/button");
    public static final By CONFIRM = By.xpath("/html/body/div[5]/div/div[6]/button[1]");

}
