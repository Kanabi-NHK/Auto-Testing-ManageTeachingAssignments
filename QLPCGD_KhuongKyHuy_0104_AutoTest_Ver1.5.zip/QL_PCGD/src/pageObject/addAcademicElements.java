package pageObject;

import org.openqa.selenium.By;

public class addAcademicElements {

    public static final By MA_HOCHAM_HOCVI_INPUT = By.id("id");
    public static final By TEN_HOCHAM_HOCVI_INPUT = By.id("name");
    public static final By THUTU_INPUT = By.id("level");
    
    public static final By SEARCH = By.xpath("//*[@id=\"tblAcademicDegree_filter\"]/label/input");
    public static final By ADD_ACADEMIC_BUTTON = By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div/div/div[1]/div[2]/div/div[2]/button/span");
    public static final By CLOSE_BUTTON = By.xpath("/html/body/div[5]/div[1]/button");
    public static final By UPDATE_BUTTON = By.xpath("//*[@id=\"tblAcademicDegree\"]/tbody/tr[1]/td[5]/a[1]/i");
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"academicdegree-form\"]/div[4]/button[2]");
    public static final By DELETE_BUTTON = By.xpath("//*[@id=\"tblAcademicDegree\"]/tbody/tr[1]/td[5]/a[2]/i");
    public static final By CONFIRM_DELETE_BUTTON = By.xpath("/html/body/div[3]/div/div[6]/button[1]");
}
