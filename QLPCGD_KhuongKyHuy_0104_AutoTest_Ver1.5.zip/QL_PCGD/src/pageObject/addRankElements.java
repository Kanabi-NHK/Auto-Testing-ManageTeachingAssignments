package pageObject;

import org.openqa.selenium.By;

public class addRankElements {

    public static final By MA_HOCHAM_HOCVI_INPUT = By.id("select2-academic_degree_id-container");
    public static final By MA_CAPBAC_INPUT = By.id("id");
    
    public static final By ADD_MAJOR_BUTTON = By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div/div/div[1]/div[2]/div/div[2]/button/span");
    public static final By CLOSE_BUTTON = By.xpath("/html/body/div[5]/div[1]/button");
    public static final By UPDATE_BUTTON = By.xpath("//*[@id=\"tblAcademicDegreeRank\"]/tbody/tr[2]/td[2]/a[1]/i");
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"academicdegreerank-form\"]/div[3]/button[2]");
    public static final By SEARCH = By.xpath("//*[@id=\"tblAcademicDegreeRank_filter\"]/label/input");
    public static final By DELETE_BUTTON = By.xpath("//*[@id=\"tblAcademicDegreeRank\"]/tbody/tr[2]/td[2]/a[2]/i");
    public static final By CONFIRM_DELETE_BUTTON = By.xpath("/html/body/div[3]/div/div[6]/button[1]");
}
