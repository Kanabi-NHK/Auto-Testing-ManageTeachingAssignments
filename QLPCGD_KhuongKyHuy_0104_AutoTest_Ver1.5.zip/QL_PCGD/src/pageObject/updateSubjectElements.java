package pageObject;

import org.openqa.selenium.By;

public class updateSubjectElements {

    public static final By UPDATE_SUBJECT = By.xpath("//*[@id=\"tblSubject\"]/tbody/tr[1]/td[6]/a/i");
    public static final By SEARCH = By.xpath("//*[@id=\"tblSubject_filter\"]/label/input");
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"subject-form\"]/div[4]/button[2]");
    public static final By CLOSE_BUTTON = By.xpath("/html/body/div[5]/div[1]/button");
    
      
}
