package pageObject;

import org.openqa.selenium.By;

public class searchUserElements {
	public static final By TITLE = By.xpath("//label[contains(text(),'Tìm kiếm:')]");
    public static final By MA_GIANG_VIEN_LABEL = By.xpath("/html/body/div[3]/div[2]/form/div[1]/label");
    public static final By MA_GIANG_VIEN_INPUT = By.id("staff_id");
    public static final By TEN_GIANG_VIEN_LABEL = By.xpath("/html/body/div[3]/div[2]/form/div[2]/label");
    public static final By SEACH = By.xpath("//input[@placeholder='Nhập tìm kiếm...']");
    public static final By HIENTHI = By.xpath("//select[@name='tblUser_length']");
    public static final By CHOSE_ROLE = By.id("UserRole");
    public static final By CHOSE_GV = By.id("UserType");
    
    public static final By ADD_USER_BUTTON = By.xpath("//input[@placeholder='Nhập tìm kiếm...']");
    public static final By CLOSE_BUTTON = By.xpath("//td[contains(text(),'Trương Vô Kỵ')]");
    //Submit button
    public static final By SUBMIT_BUTTON = By.xpath("/html/body/div[3]/div[2]/form/div[7]/button[2]");
}
