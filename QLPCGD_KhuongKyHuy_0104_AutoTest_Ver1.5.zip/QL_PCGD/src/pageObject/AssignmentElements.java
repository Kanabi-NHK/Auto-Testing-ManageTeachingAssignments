package pageObject;

import org.openqa.selenium.By;

public class AssignmentElements {

    public static final By TERM = By.xpath("//*[@id=\\\"select2-term-container\\\"]");
    public static final By MAJOR = By.xpath("//*[@id=\\\"select2-major-container\\");
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"popover307493\"]/div[2]/div/button[1]/i");
    public static final By DATA = By.xpath("//*[@id=\"popover321037\"]/div[2]/div/div/span[2]/span/span[1]/input");

    public static final By DELETE = By.xpath("//*[@id=\"popover307493\"]/div[2]/div/button[2]");    
    public static final By CONFIRM_PHANCONG = By.xpath("//*[@id=\\\"popover818040\\\"]/div[2]/div/button[1]/i");
    public static final By CONFIRM_DELETE = By.xpath("/html/body/div[6]/div/div[6]/button[1]");
    public static final By DATA_DELETE = By.xpath("/html/body/div[6]/div/input[1]");
}
