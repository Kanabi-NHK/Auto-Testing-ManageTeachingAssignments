package pageObject;

import org.openqa.selenium.By;

public class addTermElements {

    public static final By MA_TERM_INPUT = By.id("id");
    public static final By YEAR_START_SELECT = By.id("select2-start_year-container");
    public static final By YEAR_END_SELECT = By.id("select2-end_year-container");
    public static final By WEEK_INPUT = By.id("start_week");
    public static final By LESSON_INPUT = By.id("max_lesson");
    public static final By CLASS_INPUT = By.id("max_class");
   
    public static final By STATUS = By.xpath("//*[@id=\"tblTerm\"]/tbody/tr[1]/td[8]/div/input"); 
    public static final By SEARCH = By.xpath("//*[@id=\"tblTerm_filter\"]/label/input"); 
    public static final By ADD_TERM_BUTTON = By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div/div/div/div[2]/div/div/div[1]/div[2]/div/div[2]/button");
    public static final By CLOSE_BUTTON = By.xpath("/html/body/div[5]/div[1]/button");
    public static final By SUBMIT_BUTTON = By.xpath("//*[@id=\"term-form\"]/div[7]/button[2]");
    public static final By UPDATE_BUTTON = By.xpath("//*[@id=\"tblTerm\"]/tbody/tr[3]/td[9]/a[1]/i");
    public static final By DELETE_BUTTON = By.xpath("//*[@id=\"tblTerm\"]/tbody/tr[5]/td[9]/a[2]/i");
    public static final By CONFIRM_DELETE_BUTTON = By.xpath("/html/body/div[3]/div/div[6]/button[1]");
    
}
