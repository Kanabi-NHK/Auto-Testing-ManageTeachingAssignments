package pageObject;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
public class importTKBElements {
	public static final By TKB_LABEL = By.xpath("//h4[contains(text(),'Import TKB')]");
    public static final By HOCKY_LABEL = By.xpath("//label[contains(text(),'Học kỳ:')]");
    public static final By HOCKY_INPUT = By.xpath("//div[@class='row mb-1']//div[1]//div[1]");
    public static final By NGHANH_LABEL = By.xpath("//label[contains(text(),'Ngành:')]");
    public static final By NGHANH_INPUT = By.xpath("//body[1]/div[2]/div[2]/div[3]/div[1]/section[1]/div[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[2]/div[1]/span[1]/span[1]/span[1]");
    public static final By IMPORT_TKB = By.xpath("//div[contains(text(),'Kéo thả hoặc nhấn chọn để upload.')]");
  
    public static final By ADD_USER_BUTTON = By.xpath("//i[@class='ficon feather feather-maximize']");
    public static final By CLOSE_BUTTON = By.xpath("//button[contains(text(),'Huỷ')]");
    public static final By UPDATE_BUTTON = By.xpath("//button[contains(text(),'Cập nhật')]");
    public static final By UPDATE_NEXT = By.xpath("//button[contains(text(),'Import tiếp')]");
    public static final By OKT_BUTTON = By.xpath("/html/body/div[4]/div/div[6]/button[1]");

    public static final By Replace_BUTTON = By.xpath("//button[contains(text(),'Thay thế')]");

    //Submit button
    public static final By SUBMIT_BUTTON = By.xpath("//span[normalize-space()='Import']");
    
public void uploadfile() throws InterruptedException, AWTException {

    StringSelection ss = new StringSelection("D:\\VanlangUniversity\\KiemThu\\TKB\\CNTT UIS-ThoiKhoaBieu_TieuChuan_Mau.xlsx");
	Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
	
	Robot robot = new Robot(); 
	robot.keyPress(KeyEvent.VK_CONTROL); 
	robot.keyPress(KeyEvent. VK_V); 
	robot.keyRelease(KeyEvent.VK_V); 
	robot.keyRelease(KeyEvent.VK_CONTROL); 
	robot.keyPress(KeyEvent. VK_ENTER); 
	robot.keyRelease(KeyEvent.VK_ENTER);
	
	Thread.sleep(2000);
	
}
}
