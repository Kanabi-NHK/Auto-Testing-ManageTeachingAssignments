package pageObject;

import org.openqa.selenium.By;

public class addUserElements {

    public static final By MA_GIANG_VIEN_INPUT = By.id("staff_id");
    public static final By TEN_GIANG_VIEN_INPUT = By.id("full_name");
    public static final By EMAIL_INPUT = By.id("email");
    public static final By LOAI_GIANG_VIEN_SELECT = By.xpath("//*[@id=\"select2-type-container\"]/span");
    public static final By ROLE_SELECT = By.xpath("/html/body/div[3]/div[2]/form/div[5]/div/span/span[1]/span/span[1]");
    

    public static final By QUOC_TICH_INPUT = By.id("nationality");   
    public static final By ADD_USER_BUTTON = By.xpath("/html/body/div[2]/div[2]/div[3]/div/section/div[2]/div[2]/div/div/div[1]/div[2]/div/div[2]/button");
    public static final By CLOSE_BUTTON = By.xpath("/html/body/div[3]/div[1]/button");
    public static final By SUBMIT_BUTTON = By.xpath("/html/body/div[3]/div[2]/form/div[7]/button[2]");
    public static final By UPDATE_BUTTON = By.xpath("//*[@id=\"tblUser\"]/tbody/tr[1]/td[7]/a[1]/i");
    public static final By DELETE_BUTTON = By.xpath("//*[@id=\"tblUser\"]/tbody/tr[3]/td[7]/a[2]/i");
    public static final By CONFIRM_DELETE_BUTTON = By.xpath("/html/body/div[3]/div/div[6]/button[1]");
    public static final By CHON = By.xpath("//*[@id=\"tblUser\"]/thead/tr/th[6]");
    public static final By ID = By.xpath("//*[@id=\"tblUser\"]/thead/tr/th[2]");
    public static final By MAIL = By.xpath("//*[@id=\"tblUser\"]/thead/tr/th[4]");

}
