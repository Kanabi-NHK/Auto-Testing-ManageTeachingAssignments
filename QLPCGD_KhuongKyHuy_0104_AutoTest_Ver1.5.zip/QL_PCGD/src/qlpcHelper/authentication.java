package qlpcHelper;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;

public class authentication {
	WebDriver driver;
		
	public authentication(WebDriver driver) {
			this.driver = driver;
		}

	public void login() throws InterruptedException {
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.navigate().to("https://cntttest.vanlanguni.edu.vn:18081/Phancong02/Account/Login");
		driver.findElement(By.id("details-button")).click();
	    Thread.sleep(1000);
	    driver.findElement(By.id("proceed-link")).click();
	    Thread.sleep(1000);
	    driver.manage().addCookie(new Cookie(".AspNet.Cookies","74ewxYw9XIaGRM2GlhhraLlB_Ibea1aw7SEm-nnS49jmZexBRXyPuPXE1yJvvsuiX6rfoG1aouWDbuaq392BfQpVZIcOYCreIE4FCiXB-LPw0ldHmuMOR4wSdwlId0f3CB2jkHBbcvHKCZ67X_r6gHPSdFROVuMrPHSIECJCiypbN-d-H4r-qYqMyAMX2Z8zHahtfDPqSxnmyhLLHHdzlk4wbZN1P7oeN9BXEPLpPW0PidcEM5NYRXQWLzwC-1_svBDIVLrJgTj-xSjOoer36-fA_T5ugNp_Sb-ofJQy04G1qpkj9PnlOgZHrfaKLDGHYx0wwCY9bkoh03nTx503vRnGAHxQPIwyh1XpExN8aoeP7FDoggd1wrQNMkSYevzZlyhk2YObhew6UukbdFmcQgHuUzWoNod3ydMvkqsJ_KfvR1odi4Khbzqerlz2ixNEwAkFTe-sqKF8zUCvtClDDO2S3dnG6qQa5d2KeV2X9M9NVHNGr58dXYhhAVzMOjCONU1njFCWS48y3HdKH7hhNMq3tHDL66ftDSVXTjJtGUYoA3-RO_YvRV2WH5L68MVnAHRTkytyhuhVA3M0bSkTHsq_KAsemYRaWCFsr4J63jEXpJCF4HleAZWR-Gbyq-mKODSTbN78s0jZbfPCACZ4PhvpUEbxtdRbV8CYI5MCXCqTdiskuPL4sN1_UKGtedT2FWlboQk4zjuvT_V4aWRIa4WyzIUHQQGVa0HkPLlYGtU8VM1AlS10vZAwxZw7Dk-M8Q7I5AF83Ps0Ep4dGxIg8ti-mndH16u2bEdrctFzTEewLCqpl_6Vf48fQ75QyuDTucJWDEG3iW6b7KugsmYfFzdcpXkQq2pNEHGPKFHi4HoeDLmdnCaO9LuMQEmvAukYxHx0GmHm98y5z31YsyzH52qPS7wXHnEgDL-cso0Dq851cB3EJW2rjeyOsbwgqjEqzebbf8np739X8YjaxIDnC_ELKOfVv3OP3v5ZD1qB2rKzSrg6OYS0FO9SYpGvwX9LjvBvHbwb5WzTrPU_9EJu3auzXbSN4MEZUi2w9Tu3xV_yiTBj3xTQj6qEjNLyYVM3K1MPhpGpi3U_3Ctut6PghHweEoWfnXJp_VLtqBF3ZnYyIivxJYNuxluSSL47n1iazQ9QG_59HlgU877jD905T__lzP9EIWtdzYhIEB2WCSLmxSHwSpJj-uhvBKxX9DLxZyawLmWWlvobLhYZhFmZN-GPsfYC_fUFb-h3ZwwvnlPNPpqDGbRCLBTzTTuST4Jb-7AP_I0u8f6387OVh4W2-fYRALjlFruK0fDDki4cegStXFbSJoxcSjgg9vgqis_pO9z1nYHzRWiZR1ILy-wwVGuteWi8ApzC-Q2l35OhE1tBDh8vOLE9n3ATGfGWne0MLemss3Zxlw78OI-PdVcrfz2WdkCZMBsNQDMa96AUs6A-hvlhE5jyqGhb9T5TGOl4LCEZuW_4kSQvueVCXUdvNXloFk_vfBXAhq_dYh5TnVc"));
	    driver.navigate().refresh();
		
	}
}
