package qlpcHelper;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.stream.JsonReader;


public class jsonTerm {
    String projectPath = System.getProperty("user.dir");

    // Constructor
    public jsonTerm() {
        // Default constructor
    }

    public List<List<String>> readDataFromJson() {
    	List<List<String>> jsonData = new ArrayList<>();
    	
    	try (JsonReader reader = new JsonReader(new FileReader(projectPath + "\\data\\termsdata.json"))) {
			reader.beginArray();

			while (reader.hasNext()) {

				reader.beginObject();

				while (reader.hasNext()) {
					List<String> rowData = new ArrayList<>();
					
					String name = reader.nextName();
					if (name.equals("term")) {
						rowData.add(reader.nextString());
					} else if (name.equals("yearstart")) {
						rowData.add(reader.nextString());
					} else if (name.equals("yearend")) {
						rowData.add(reader.nextString());
					} else if (name.equals("weekstart")) {
						rowData.add(reader.nextString());
					} else if (name.equals("maxlesson")) {
						rowData.add(reader.nextString());
					} else if (name.equals("maxclass")) {
						rowData.add(reader.nextString());
					}
					jsonData.add(rowData);
				}
				reader.endObject();
			}

			reader.endArray();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	
    	return jsonData;
    }
}
