package qlpcHelper;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.stream.JsonReader;


public class jsonAcademic {
    String projectPath = System.getProperty("user.dir");

    // Constructor
    public jsonAcademic() {
        // Default constructor
    }

    public List<List<String>> readDataFromJson() {
    	List<List<String>> jsonData = new ArrayList<>();
    	
    	try (JsonReader reader = new JsonReader(new FileReader(projectPath + "\\data\\academicsdata.json"))) {
			reader.beginArray();

			while (reader.hasNext()) {

				reader.beginObject();

				while (reader.hasNext()) {
					List<String> rowData = new ArrayList<>();
					
					String name = reader.nextName();
					if (name.equals("academicId")) {
						rowData.add(reader.nextString());
					} else if (name.equals("academicName")) {
						rowData.add(reader.nextString());
					} else if (name.equals("levels")) {
						rowData.add(reader.nextString());
					} 
						jsonData.add(rowData);
				}
				reader.endObject();
			}

			reader.endArray();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	
    	return jsonData;
    }
}
