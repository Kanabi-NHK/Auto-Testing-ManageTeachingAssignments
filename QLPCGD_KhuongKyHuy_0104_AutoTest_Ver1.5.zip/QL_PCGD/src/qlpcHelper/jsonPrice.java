package qlpcHelper;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.stream.JsonReader;


public class jsonPrice {
    String projectPath = System.getProperty("user.dir");

    // Constructor
    public jsonPrice() {
        // Default constructor
    }

    public List<List<String>> readDataFromJson() {
    	List<List<String>> jsonData = new ArrayList<>();
    	
    	try (JsonReader reader = new JsonReader(new FileReader(projectPath + "\\data\\pricedata.json"))) {
			reader.beginArray();

			while (reader.hasNext()) {

				reader.beginObject();

				while (reader.hasNext()) {
					List<String> rowData = new ArrayList<>();
					
					String name = reader.nextName();
					if (name.equals("price")) {
						rowData.add(reader.nextString());
					} else if (name.equals("TV")) {
						rowData.add(reader.nextString());
					} else if (name.equals("TA")) {
						rowData.add(reader.nextString());
					} else if (name.equals("LT")) {
						rowData.add(reader.nextString());
					} else if (name.equals("TH")) {
						rowData.add(reader.nextString());
					}
					jsonData.add(rowData);
				}
				reader.endObject();
			}

			reader.endArray();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	
    	return jsonData;
    }
}
