package qlpcHelper;

import java.io.FileReader; 
import java.util.ArrayList;
import java.util.List;

import com.google.gson.stream.JsonReader;


public class jsonSearchUser {
    String projectPath = System.getProperty("user.dir");

    // Constructor
    public jsonSearchUser() {
        // Default constructor
    }

    public List<List<String>> readDataFromJson() {
    	List<List<String>> jsonData = new ArrayList<>();
    	
    	try (JsonReader reader = new JsonReader(new FileReader(projectPath + "\\data\\searchdata.json"))) {
			reader.beginArray();

			while (reader.hasNext()) {

				reader.beginObject();

				while (reader.hasNext()) {
					List<String> rowData = new ArrayList<>();
					
					String name = reader.nextName();
					if (name.equals("userId")) {
						rowData.add(reader.nextString());
					} else if (name.equals("fullname")) {
						rowData.add(reader.nextString());
					} else if (name.equals("email")) {
						rowData.add(reader.nextString());
					} else if (name.equals("category")) {
						rowData.add(reader.nextString());
					} else if (name.equals("role")) {
						rowData.add(reader.nextString());
					} else if (name.equals("hienthi")) {
						rowData.add(reader.nextString());
					}
					jsonData.add(rowData);
				}
				reader.endObject();
			}

			reader.endArray();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	
    	return jsonData;
    }
}
